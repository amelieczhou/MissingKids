<html>
    <head>
        <h1>hello,{{$name}}</h1>
    </head>
</html>