<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('common.validator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- 自定义内容区域 -->
    <div class="panel panel-default">
        <div class="panel-heading">新增学生</div>
        <div class="panel-body">
            <?php echo $__env->make('student._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('common.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>