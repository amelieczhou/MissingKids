<html>
    <head>
        <h1>hello,<?php echo e($name); ?></h1>
    </head>
</html>